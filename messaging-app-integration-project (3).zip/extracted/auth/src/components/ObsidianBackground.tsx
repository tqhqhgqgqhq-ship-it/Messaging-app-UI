import { useEffect, useRef } from "react";

export default function ObsidianBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouse = useRef({ x: 0.5, y: 0.35 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    let w = (canvas.width = canvas.offsetWidth * window.devicePixelRatio);
    let h = (canvas.height = canvas.offsetHeight * window.devicePixelRatio);
    
    const particles = Array.from({ length: 38 }, () => ({
      x: Math.random(),
      y: Math.random(),
      r: 0.6 + Math.random() * 1.1,
      vx: (Math.random() - 0.5) * 0.00009,
      vy: (Math.random() - 0.5) * 0.00009,
      a: 0.18 + Math.random() * 0.28,
    }));

    let raf = 0;
    const tick = () => {
      ctx.clearRect(0,0,w,h);

      // soft vignette
      const vg = ctx.createRadialGradient(w*0.52, h*0.54, 0, w*0.52, h*0.54, Math.max(w,h)*0.78);
      vg.addColorStop(0, "rgba(17,14,22,0.00)");
      vg.addColorStop(1, "rgba(0,0,0,0.55)");
      ctx.fillStyle = vg;
      ctx.fillRect(0,0,w,h);

      // moving specular sheen
      const mx = mouse.current.x * w;
      const my = mouse.current.y * h;
      const sheen = ctx.createRadialGradient(mx, my, 0, mx, my, Math.max(w,h)*0.58);
      sheen.addColorStop(0, "rgba(255,249,236,0.036)");
      sheen.addColorStop(0.25, "rgba(255,244,226,0.016)");
      sheen.addColorStop(1, "rgba(255,255,255,0)");
      ctx.fillStyle = sheen;
      ctx.fillRect(0,0,w,h);

      // fine grain
      ctx.globalAlpha = .018;
      for (let i = 0; i < 40; i++) {
        ctx.fillStyle = Math.random() > .5 ? "#fff" : "#d9d1c6";
        ctx.fillRect(Math.random()*w, Math.random()*h, 1,1);
      }
      ctx.globalAlpha = 1;

      // particles
      for (const p of particles) {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0 || p.x > 1) p.vx *= -1;
        if (p.y < 0 || p.y > 1) p.vy *= -1;
        const px = p.x * w;
        const py = p.y * h;
        ctx.beginPath();
        ctx.arc(px, py, p.r * window.devicePixelRatio * 1.25, 0, Math.PI*2);
        ctx.fillStyle = `rgba(235,227,213,${p.a * 0.65})`;
        ctx.fill();
      }

      // connecting faint threads near mouse
      ctx.strokeStyle = "rgba(231,224,214,0.065)";
      ctx.lineWidth = 1;
      particles.forEach((p,i)=>{
        const px = p.x * w, py = p.y * h;
        const dx = px - mx, dy = py - my;
        const dist = Math.sqrt(dx*dx+dy*dy);
        if (dist < 170 * window.devicePixelRatio) {
          const n = particles[(i+7)%particles.length];
          ctx.beginPath();
          ctx.moveTo(px, py);
          ctx.lineTo(n.x * w, n.y * h);
          ctx.stroke();
        }
      });

      raf = requestAnimationFrame(tick);
    };
    tick();

    const onResize = () => {
      w = canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      h = canvas.height = canvas.offsetHeight * window.devicePixelRatio;
    };
    const onMove = (e: MouseEvent | TouchEvent) => {
      const rect = canvas.getBoundingClientRect();
      const clientX = 'touches' in e ? e.touches[0]?.clientX ?? mouse.current.x * rect.width : (e as MouseEvent).clientX;
      const clientY = 'touches' in e ? e.touches[0]?.clientY ?? mouse.current.y * rect.height : (e as MouseEvent).clientY;
      mouse.current.x = (clientX - rect.left) / rect.width;
      mouse.current.y = (clientY - rect.top) / rect.height;
    };

    window.addEventListener("resize", onResize);
    window.addEventListener("mousemove", onMove, { passive: true });
    window.addEventListener("touchmove", onMove, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("touchmove", onMove);
    };
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden bg-[#050507]">
      {/* deep obsidian layers */}
      <div className="absolute inset-0"
        style={{
          background:
            "radial-gradient(1200px 820px at 18% -8%, rgba(84,70,52,0.054), transparent 60%), radial-gradient(950px 700px at 88% 18%, rgba(110,93,73,0.035), transparent 60%), radial-gradient(900px 700px at 50% 108%, rgba(52,51,63,0.13), transparent 60%), linear-gradient(180deg, #08080b 0%, #050507 42%, #040406 100%)"
        }}
      />
      {/* brushed metal vertical lines */}
      <div className="absolute inset-0 opacity-[0.075]" style={{
        backgroundImage:
          "repeating-linear-gradient(90deg, rgba(255,255,255,0.044) 0px, rgba(255,255,255,0.044) 1px, transparent 1px, transparent 110px)",
      }}/>
      {/* soft grid */}
      <div className="absolute inset-0 opacity-[0.028]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,248,235,0.15) 1px, transparent 1px), linear-gradient(90deg, rgba(255,248,235,0.10) 1px, transparent 1px)",
          backgroundSize: "96px 96px",
        }}
      />
      {/* top reflective edge */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/[0.20] to-transparent" />
      {/* ambient glows */}
      <div className="absolute -top-32 -left-32 w-[620px] h-[520px] rounded-full blur-[140px] opacity-[0.14]" style={{ background: "radial-gradient(circle, #c5b49c 0%, #7e6a52 60%, transparent 75%)"}}/>
      <div className="absolute top-24 right-[-80px] w-[460px] h-[430px] rounded-full blur-[120px] opacity-[0.10]" style={{ background: "radial-gradient(circle, #d9cfc0 0%, transparent 70%)"}}/>
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full opacity-[1]" />
      {/* bottom floor reflection */}
      <div className="absolute bottom-0 inset-x-0 h-[33vh]"
        style={{
          background:
            "linear-gradient(to top, rgba(255,248,232,0.028), rgba(255,248,232,0.006) 36%, transparent)",
          maskImage: "linear-gradient(to top, black, transparent)"
        }}
      />
    </div>
  );
}
