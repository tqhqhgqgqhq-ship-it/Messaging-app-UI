import { useState } from 'react';

/* ============================ ICONS ============================ */
const I = {
  Search: ({ s = 16 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
      <circle cx="11" cy="11" r="7.5"/><path d="m20.5 20.5-4-4"/>
    </svg>
  ),
  Tune: ({ s = 17 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
      <path d="M21 5H10M6 5H3M21 12h-3M13 12H3M21 19h-7M9 19H3"/>
      <circle cx="8" cy="5" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="11" cy="19" r="2"/>
    </svg>
  ),
  Plus: ({ s = 18 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.8" strokeLinecap="round">
      <path d="M12 5v14M5 12h14"/>
    </svg>
  ),
  Star: ({ s = 12 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
    </svg>
  ),
  Mute: ({ s = 12 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 5 6 9H2v6h4l5 4V5Z"/><path d="m22 9-6 6M16 9l6 6"/>
    </svg>
  ),
  Pin: ({ s = 13 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 17v5M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1Z"/>
    </svg>
  ),
  Chat: ({ s = 20 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
      <circle cx="8.5" cy="11.5" r="0.9" fill="currentColor" stroke="none"/>
      <circle cx="12" cy="11.5" r="0.9" fill="currentColor" stroke="none"/>
      <circle cx="15.5" cy="11.5" r="0.9" fill="currentColor" stroke="none"/>
    </svg>
  ),
  Phone: ({ s = 20 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
    </svg>
  ),
  People: ({ s = 20 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
      <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
    </svg>
  ),
  Gear: ({ s = 20 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.1a2 2 0 0 1-1-1.72v-.51a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/>
      <circle cx="12" cy="12" r="3"/>
    </svg>
  ),
  Sparkle: ({ s = 12 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 1.5l1.8 5.7 5.7 1.8-5.7 1.8L12 16.5l-1.8-5.7L4.5 9l5.7-1.8zM19.5 14l.9 2.85 2.85.9-2.85.9-.9 2.85-.9-2.85-2.85-.9 2.85-.9z"/>
    </svg>
  ),
};

/* ============================ DATA ============================ */
const AVATARS = {
  me: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&h=120&fit=crop',
  aarav: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=160&h=160&fit=crop',
  diya: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=160&h=160&fit=crop',
  kabir: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=160&h=160&fit=crop',
  ananya: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=160&h=160&fit=crop',
  circle: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=160&h=160&fit=crop',
  friends: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=160&h=160&fit=crop',
  photo: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=120&h=120&fit=crop',
};

type Chat = {
  img: string; name: string; msg: string; time: string;
  unread?: number; online?: boolean; star?: boolean; muted?: boolean;
  pinned?: boolean; photo?: boolean; group?: boolean; mention?: boolean;
};

const CHATS: Chat[] = [
  { img: AVATARS.aarav, name: 'Aarav Mehta', msg: "Let's catch up over coffee this weekend? ☕", time: '9:40 AM', unread: 2, online: true, star: true },
  { img: AVATARS.diya, name: 'Diya Shah', msg: 'That sounds amazing! ✨', time: '9:32 AM', online: true, pinned: true },
  { img: AVATARS.circle, name: 'Project Phoenix', msg: 'Rohan: Please review the latest slides.', time: 'Yesterday', unread: 8, muted: true, group: true, mention: true },
  { img: AVATARS.kabir, name: 'Kabir Singh', msg: 'Shared a photo', time: 'Yesterday', photo: true },
  { img: AVATARS.ananya, name: 'Ananya Iyer', msg: 'Thank you so much! 😊', time: 'Tue', online: true, unread: 1 },
  { img: AVATARS.friends, name: 'Friends Forever', msg: 'Diya: Hahaha true 😂', time: 'Mon', unread: 3, muted: true, group: true, mention: true },
  { img: AVATARS.kabir, name: 'Design Guild', msg: 'Kabir: Final tokens are pushed 🎨', time: 'Mon', group: true },
  { img: AVATARS.diya, name: 'Diya · Work', msg: 'Sent the invoice, check inbox.', time: 'Sun', unread: 1, mention: true },
  { img: AVATARS.aarav, name: 'Aarav · Gym', msg: 'Leg day tomorrow 6 AM. No excuses.', time: 'Sun', online: true },
  { img: AVATARS.circle, name: 'Family Circle', msg: 'Mom: Dinner at 8, everyone!', time: 'Sat', group: true, muted: true },
];

const STORIES = [
  { name: 'New Nudge', newNudge: true },
  { name: 'My Circle', img: AVATARS.circle, active: true },
  { name: 'Aarav', img: AVATARS.aarav, online: true },
  { name: 'Diya', img: AVATARS.diya, online: true },
  { name: 'Kabir', img: AVATARS.kabir },
  { name: 'Ananya', img: AVATARS.ananya, online: true },
];

/* ============================ ATOMS ============================ */
const GoldAvatar = ({ img, size, online, dim }: { img: string; size: number; online?: boolean; dim?: boolean }) => (
  <div className="relative flex-shrink-0">
    <div
      style={{
        width: size, height: size, borderRadius: '50%', padding: 2,
        background: dim
          ? 'linear-gradient(160deg, #3A332A, #221E18)'
          : 'conic-gradient(from 210deg, #8F6420 0%, #D9AE5F 12%, #FFF0CC 25%, #E2B566 38%, #9C7126 52%, #C8963F 68%, #F3D392 80%, #B07F2C 92%, #8F6420 100%)',
        boxShadow: dim ? 'none' : '0 0 8px rgba(216,173,90,0.15), 0 2px 6px rgba(0,0,0,0.5)',
      }}
    >
      <div style={{ width: '100%', height: '100%', borderRadius: '50%', padding: 1.5, background: '#0C0A07' }}>
        <img src={img} alt="" className="w-full h-full object-cover rounded-full" draggable={false} />
      </div>
    </div>
    {online && (
      <span
        className="online-dot absolute rounded-full"
        style={{ width: size * 0.24, height: size * 0.24, bottom: size * 0.02, right: size * 0.02, border: '2px solid #0B0907' }}
      />
    )}
  </div>
);

const GoldBadge = ({ n, small }: { n: number; small?: boolean }) => (
  <span
    className="gold-solid inline-flex items-center justify-center rounded-full font-extrabold text-black flex-shrink-0"
    style={{
      minWidth: small ? 17 : 22, height: small ? 17 : 22,
      fontSize: small ? 10 : 11, padding: '0 5px',
      textShadow: '0 1px 0 rgba(255,243,214,0.55)',
    }}
  >
    {n}
  </span>
);

/* ============================ SECTIONS ============================ */

const Header = () => (
  <div className="flex items-start justify-between px-5 pt-3 pb-2 flex-shrink-0">
    <div className="flex flex-col">
      <div className="flex items-start gap-[2px]">
        <h1 className="logo-shimmer text-[26px] font-extrabold tracking-[-0.03em] leading-none select-none">Nudgel</h1>
        <span className="text-[#F0CC85] mt-[-2px]" style={{ filter: 'drop-shadow(0 0 3px rgba(240,204,133,0.6))' }}>
          <I.Sparkle s={11} />
        </span>
      </div>
      <p className="text-[11px] font-medium text-[#9B8F7C] mt-1 tracking-wide">
        Messaging, but better<span className="ml-1 inline-block w-[4px] h-[4px] rounded-full align-middle gold-solid" />
      </p>
    </div>
    <div className="flex items-center gap-2.5">
      <button className="tappable-soft relative" aria-label="Profile">
        <GoldAvatar img={AVATARS.me} size={36} />
        <span
          className="absolute -bottom-0.5 -right-0.5 w-[11px] h-[11px] rounded-full gold-solid"
          style={{ border: '2px solid #0B0907' }}
        />
      </button>
    </div>
  </div>
);

const SearchRow = () => (
  <div className="flex items-center gap-2.5 px-4 pb-2.5 flex-shrink-0">
    <div className="luxe-surface flex-1 flex items-center gap-2.5 rounded-2xl px-3.5 h-[40px]">
      <span className="text-[#8A7D67]"><I.Search s={16} /></span>
      <input
        type="text"
        placeholder="Search Nudges or people"
        className="flex-1 bg-transparent text-[13px] font-medium text-[#F3EADB] placeholder-[#6E6353] outline-none min-w-0"
      />
    </div>
    <button aria-label="Filters" className="gold-solid tappable w-[40px] h-[40px] rounded-2xl flex items-center justify-center text-black flex-shrink-0">
      <I.Tune s={17} />
    </button>
  </div>
);

const Stories = () => (
  <div className="flex-shrink-0">
    <div className="scroll-x flex gap-4 px-4 pb-1.5 items-start">
      {STORIES.map((s, i) => (
        <button key={i} className="tappable-soft flex flex-col items-center gap-1.5 flex-shrink-0 w-[64px]">
          {'newNudge' in s && s.newNudge ? (
            <div className="relative">
              <div
                className="w-[58px] h-[58px] rounded-[19px] flex items-center justify-center"
                style={{
                  background: 'linear-gradient(165deg, #221D15 0%, #161209 100%)',
                  border: '1.5px solid rgba(216,173,90,0.4)',
                  boxShadow: '0 0 12px rgba(216,173,90,0.2), 0 1px 0 rgba(255,235,190,0.08) inset, 0 4px 10px rgba(0,0,0,0.5)',
                }}
              >
                <span className="text-[#EFC878]"><I.Chat s={24} /></span>
              </div>
              <span className="absolute -top-1 -right-1 text-[#FFE9B8]" style={{ filter: 'drop-shadow(0 0 4px rgba(255,233,184,0.7))' }}>
                <I.Sparkle s={14} />
              </span>
            </div>
          ) : (
            <GoldAvatar img={(s as any).img} size={58} online={(s as any).online} dim={!(s as any).active && !(s as any).online} />
          )}
          <span className={`text-[10.5px] font-semibold leading-tight truncate w-full text-center ${(s as any).active ? 'text-[#EFC878]' : 'text-[#9B8F7C]'}`}>
            {s.name}
          </span>
          {(s as any).active && (
            <span className="grow-bar block w-5 h-[2.5px] rounded-full gold-solid -mt-0.5" />
          )}
        </button>
      ))}
    </div>
  </div>
);

const ChatRow = ({ c, delay }: { c: Chat; delay: number }) => (
  <button
    className="chat-row rise-in w-full flex items-center gap-3 px-3 py-[10px] rounded-[18px] text-left"
    style={{ animationDelay: `${delay}ms` }}
  >
    <GoldAvatar img={c.img} size={48} online={c.online} dim={!c.unread && !c.star} />
    <div className="flex-1 min-w-0">
      <div className="flex items-center justify-between gap-2 mb-[2px]">
        <span className="flex items-center gap-1.5 min-w-0">
          <span className="text-[13.5px] font-bold text-[#F3EADB] truncate tracking-[-0.01em]">{c.name}</span>
          {c.star && (
            <span className="text-[#EFC878] flex-shrink-0" style={{ filter: 'drop-shadow(0 0 3px rgba(239,200,120,0.55))' }}>
              <I.Star s={11} />
            </span>
          )}
          {c.muted && <span className="text-[#5A5142] flex-shrink-0"><I.Mute s={11} /></span>}
        </span>
        <span className={`text-[10.5px] font-semibold flex-shrink-0 ${c.unread ? 'text-[#C9A969]' : 'text-[#6E6353]'}`}>
          {c.time}
        </span>
      </div>
      <div className="flex items-center justify-between gap-2">
        <span className={`text-[12px] truncate ${c.unread ? 'text-[#C9BCA6] font-semibold' : 'text-[#80755F] font-medium'}`}>
          {c.mention && <span className="text-[#EFC878] font-bold mr-1">@</span>}
          {c.msg}
        </span>
        <span className="flex items-center gap-1.5 flex-shrink-0">
          {c.pinned && <span className="text-[#6E6353]"><I.Pin s={13} /></span>}
          {c.photo && (
            <span
              className="block w-[30px] h-[22px] rounded-md overflow-hidden"
              style={{ border: '1.5px solid rgba(216,173,90,0.3)', boxShadow: '0 2px 5px rgba(0,0,0,0.5)' }}
            >
              <img src={AVATARS.photo} alt="" className="w-full h-full object-cover" draggable={false} />
            </span>
          )}
          {c.unread ? <GoldBadge n={c.unread} /> : null}
        </span>
      </div>
    </div>
  </button>
);

const NAV = [
  { id: 'chats', label: 'Chats', icon: I.Chat, badge: 12 },
  { id: 'calls', label: 'Calls', icon: I.Phone },
  { id: 'center', label: '', icon: null },
  { id: 'people', label: 'People', icon: I.People },
  { id: 'settings', label: 'Settings', icon: I.Gear },
];

const BottomNav = ({ active, onChange }: { active: string; onChange: (id: string) => void }) => (
  <div className="flex-shrink-0 relative z-30 px-3 pb-1.5 pt-1">
    <div
      className="relative flex items-center justify-between rounded-[24px] px-1.5 h-[60px]"
      style={{
        background: 'linear-gradient(178deg, #1C1813 0%, #110E09 70%, #0C0A06 100%)',
        border: '1px solid rgba(216,173,90,0.18)',
        boxShadow: '0 1px 0 rgba(255,235,190,0.07) inset, 0 -1px 0 rgba(0,0,0,0.7) inset, 0 -6px 22px rgba(0,0,0,0.55), 0 2px 10px rgba(0,0,0,0.5)',
      }}
    >
      {NAV.map(item => {
        if (item.id === 'center') {
          return (
            <button
              key="center"
              aria-label="Nudgel home"
              className="gold-solid hero-glow tappable relative -mt-7 w-[56px] h-[56px] rounded-full flex items-center justify-center flex-shrink-0"
              style={{ border: '3.5px solid #0B0907' }}
            >
              <span
                className="absolute rounded-full pointer-events-none"
                style={{
                  top: 3.5, left: 6, right: 6, height: '42%',
                  background: 'linear-gradient(180deg, rgba(255,250,235,0.55) 0%, rgba(255,250,235,0) 100%)',
                  borderRadius: '50% 50% 45% 45%',
                }}
              />
              <span className="text-black relative" style={{ filter: 'drop-shadow(0 1px 0 rgba(255,243,214,0.6))' }}><I.Plus s={24} /></span>
            </button>
          );
        }
        const on = active === item.id;
        const Icon = item.icon!;
        return (
          <button
            key={item.id}
            onClick={() => onChange(item.id)}
            className="tappable-soft relative flex flex-col items-center justify-center gap-[2px] w-[58px] h-full"
          >
            {on && (
              <span
                className="absolute inset-x-2 inset-y-2 rounded-xl pointer-events-none"
                style={{
                  background: 'radial-gradient(ellipse at 50% 30%, rgba(216,173,90,0.18) 0%, rgba(216,173,90,0.04) 60%, transparent 100%)',
                  border: '1px solid rgba(216,173,90,0.2)',
                }}
              />
            )}
            <span className="relative">
              <span
                className={on ? 'text-[#EFC878]' : 'text-[#6E6353]'}
                style={on ? { filter: 'drop-shadow(0 0 4px rgba(239,200,120,0.45))' } : {}}
              >
                <Icon s={19} />
              </span>
              {item.badge ? (
                <span className="absolute -top-1.5 -right-2.5">
                  <GoldBadge n={item.badge} small />
                </span>
              ) : null}
            </span>
            <span className={`text-[9.5px] font-bold tracking-wide ${on ? 'text-[#EFC878]' : 'text-[#6E6353]'}`}>
              {item.label}
            </span>
          </button>
        );
      })}
    </div>
    <div className="flex justify-center pt-2">
      <span className="w-[110px] h-[4px] rounded-full" style={{ background: 'rgba(243,234,219,0.28)' }} />
    </div>
  </div>
);

/* ============================ APP ============================ */
export default function App() {
  const [tab, setTab] = useState('chats');

  const visibleChats = CHATS;

  return (
    <div className="h-full w-full flex items-center justify-center" style={{ background: '#050403' }}>
      <div
        className="relative w-full max-w-[420px] h-full max-h-[900px] flex flex-col overflow-hidden sm:rounded-[44px]"
        style={{
          background: 'linear-gradient(178deg, #131009 0%, #0B0907 38%, #080606 100%)',
          boxShadow: '0 0 0 1px rgba(216,173,90,0.1), 0 30px 90px rgba(0,0,0,0.9)',
        }}
      >
        <div
          className="absolute top-0 inset-x-0 h-[220px] pointer-events-none"
          style={{ background: 'radial-gradient(ellipse 90% 100% at 30% 0%, rgba(216,173,90,0.085) 0%, transparent 65%)' }}
        />
        <div
          className="absolute bottom-0 inset-x-0 h-[180px] pointer-events-none"
          style={{ background: 'radial-gradient(ellipse 80% 100% at 50% 100%, rgba(216,173,90,0.06) 0%, transparent 65%)' }}
        />

        {/* ======== FIXED TOP (compact) ======== */}
        <Header />
        <SearchRow />
        <Stories />

        <div className="flex-shrink-0 px-4 pt-2">
          <div className="h-px w-full" style={{ background: 'linear-gradient(90deg, transparent, rgba(216,173,90,0.22) 50%, transparent)' }} />
        </div>

        {/* ======== SCROLLABLE — CONTACTS (70-80% area) ======== */}
        <div className="scroll-area flex-1 min-h-0 relative px-2">
          <div className="sticky top-0 h-3 -mx-2 z-10 pointer-events-none"
            style={{ background: 'linear-gradient(180deg, #0B0907 0%, transparent 100%)' }} />
          <div className="space-y-0.5 pt-1 pb-2">
            {visibleChats.map((c, i) => (
              <ChatRow key={c.name + i} c={c} delay={i * 40} />
            ))}
            {visibleChats.length === 0 && (
              <div className="flex flex-col items-center gap-3 pt-16 text-[#6E6353]">
                <I.Chat s={34} />
                <span className="text-[12px] font-semibold">Nothing here yet</span>
              </div>
            )}
          </div>
        </div>

        <div className="flex-shrink-0 h-2 -mb-2 relative z-10 pointer-events-none"
          style={{ background: 'linear-gradient(0deg, #0B0907 0%, transparent 100%)' }} />

        {/* ======== FIXED BOTTOM (compact) ======== */}
        <BottomNav active={tab} onChange={setTab} />
      </div>
    </div>
  );
}
