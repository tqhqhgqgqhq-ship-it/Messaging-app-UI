import { initializeApp } from "firebase/app";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendEmailVerification,
  signOut as fbSignOut,
  onAuthStateChanged,
  User as FirebaseUser,
  updateProfile,
  updatePassword,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
} from "firebase/auth";
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  serverTimestamp,
  Timestamp,
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyADpzxDduOe0esjAXBtQ1z0goNNH71ySt8",
  authDomain: "word-weaver-9usyc.firebaseapp.com",
  projectId: "word-weaver-9usyc",
  storageBucket: "word-weaver-9usyc.firebasestorage.app",
  messagingSenderId: "259377788064",
  appId: "1:259377788064:web:ddf54721523d2e4efb85c5",
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

export type AuthUser = {
  uid: string;
  name: string;
  email: string;
  emailVerified: boolean;
  photoURL: string | null;
  createdAt: string;
  lastSignIn: string;
  recoveryToken: string | null; // unhashed, returned only on creation/regeneration
};

// ===========================================================
// SIGN UP / SIGN IN / LOGOUT
// ===========================================================
export async function signUp(name: string, email: string, password: string) {
  const cred = await createUserWithEmailAndPassword(auth, email, password);
  if (cred.user) {
    await updateProfile(cred.user, { displayName: name });
    sendEmailVerification(cred.user).catch(() => {});
  }
  let recoveryToken: string;
  try {
    recoveryToken = await generateAndStoreRecoveryToken(cred.user.uid, email);
  } catch (e: any) {
    // Account was created in Firebase Auth, but Firestore failed.
    // Surface a clear, actionable error instead of hanging.
    throw new Error(
      "Account created, but saving the recovery token failed: " + e.message +
      " — You can sign in and regenerate it from the dashboard."
    );
  }
  return toAuthUser(cred.user, recoveryToken);
}

export async function signIn(email: string, password: string, remember: boolean) {
  await setPersistence(auth, remember ? browserLocalPersistence : browserSessionPersistence);
  const cred = await signInWithEmailAndPassword(auth, email, password);
  const user = toAuthUser(cred.user);
  // Read the recovery token (hashed version) to know one exists
  const tokenData = await getRecoveryTokenData(cred.user.uid);
  if (tokenData) user.recoveryToken = tokenData.exists ? "***" : null;
  return user;
}

export async function logout() {
  await fbSignOut(auth);
}

export function onAuthChange(cb: (user: AuthUser | null) => void) {
  return onAuthStateChanged(auth, (fbUser) => {
    cb(fbUser ? toAuthUser(fbUser) : null);
  });
}

// ===========================================================
// RECOVERY TOKEN SYSTEM (cryptographically secure)
// ===========================================================

/** Wrap a promise with a timeout so Firestore calls can't hang forever
 *  (Firestore retries indefinitely when DB doesn't exist / rules block / offline) */
function withTimeout<T>(p: Promise<T>, ms = 10000, label = "Operation"): Promise<T> {
  return Promise.race([
    p,
    new Promise<T>((_, reject) =>
      setTimeout(() => reject(new Error(
        `${label} timed out. Make sure Firestore is created in your Firebase Console ` +
        `(Build → Firestore Database → Create database) and rules allow access.`
      )), ms)
    ),
  ]);
}

/** Generate a human-friendly, high-entropy token:
 *  NUDGEL-XXXX-XXXX-XXXX  (4 chars × 3 groups, 4+4+4 chars in user-decodable base32)
 *  Excluding ambiguous chars (0,O,1,I)
 *  3 groups × 4 chars = 24^12 ≈ 6×10^16 possible tokens
 */
function generateRawToken(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const segments: string[] = [];
  for (let s = 0; s < 3; s++) {
    let seg = "";
    for (let i = 0; i < 4; i++) {
      // crypto-secure random
      const buf = new Uint32Array(1);
      crypto.getRandomValues(buf);
      seg += chars[buf[0] % chars.length];
    }
    segments.push(seg);
  }
  return "NUDGEL-" + segments.join("-");
}

/** SHA-256 hash of the token — what we store in the database */
async function hashToken(token: string): Promise<string> {
  const normalized = token.trim().toUpperCase().replace(/\s/g, "");
  const data = new TextEncoder().encode(normalized);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hashBuffer))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** Normalize a token entered by the user to its canonical form */
function normalizeToken(token: string): string {
  return token
    .trim()
    .toUpperCase()
    .replace(/\s/g, "")
    .replace(/[^A-Z0-9-]/g, "")
    .toUpperCase();
}

// Rate limiting via localStorage (Firestore-free, simple)
const RL_KEY = (email: string, op: string) => `nudgel_rl_${op}_${email.toLowerCase()}`;

function getRateLimitState(email: string, op: string): { count: number; resetAt: number } {
  try {
    const raw = localStorage.getItem(RL_KEY(email, op));
    if (!raw) return { count: 0, resetAt: 0 };
    const parsed = JSON.parse(raw);
    if (Date.now() > parsed.resetAt) return { count: 0, resetAt: Date.now() + 900_000 };
    return parsed;
  } catch { return { count: 0, resetAt: 0 }; }
}

function bumpRateLimit(email: string, op: string, max: number, windowMs: number) {
  const state = getRateLimitState(email, op);
  const newCount = state.count + 1;
  const resetAt = state.resetAt || Date.now() + windowMs;
  localStorage.setItem(RL_KEY(email, op), JSON.stringify({ count: newCount, resetAt }));
  if (newCount > max) {
    const remaining = Math.ceil((resetAt - Date.now()) / 1000);
    throw new Error(`Too many attempts. Try again in ${Math.max(remaining, 60)} seconds.`);
  }
}

function resetRateLimit(email: string, op: string) {
  localStorage.removeItem(RL_KEY(email, op));
}

/**
 * Generate and store a new recovery token for a user.
 * Returns the unhashed token (ONLY valid for one display moment).
 * In Firestore: recovery_tokens/{uid} with { tokenHash, createdAt, used: false, version }
 */
export async function generateAndStoreRecoveryToken(uid: string, email: string): Promise<string> {
  const token = generateRawToken();
  const tokenHash = await hashToken(token);

  // One active token per account — overwrite any previous
  await withTimeout(setDoc(doc(db, "recovery_tokens", uid), {
    uid,
    email: email.toLowerCase().trim(),
    tokenHash,
    createdAt: serverTimestamp(),
    used: false,
    version: Date.now(),
    createdAtTs: Timestamp.now(),
  }, { merge: false }), 10000, "Saving recovery token");

  // Also store by email for recovery lookup (when user is not signed in)
  await withTimeout(setDoc(doc(db, "recovery_by_email", email.toLowerCase().trim()), {
    uid,
    hasToken: true,
    updatedAt: serverTimestamp(),
  }), 10000, "Saving recovery index");

  return token;
}

async function getRecoveryTokenData(uid: string): Promise<{ exists: boolean } | null> {
  try {
    const snap = await withTimeout(getDoc(doc(db, "recovery_tokens", uid)), 6000, "Token lookup");
    if (!snap.exists()) return null;
    return { exists: true };
  } catch { return null; }
}

/**
 * STEP 1 of recovery: verify a recovery token for an email.
 * Looks up user by email, then checks the tokenHash.
 * Brute-force protected via rate limit.
 */
export async function verifyRecoveryToken(email: string, token: string): Promise<{ uid: string }> {
  const normEmail = email.toLowerCase().trim();
  const normToken = normalizeToken(token);

  if (!normEmail || !normToken) throw new Error("Email and recovery token are required.");

  // Validate token format (NUDGEL-XXXX-XXXX-XXXX)
  if (!/^NUDGEL-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(normToken)) {
    throw new Error("Invalid token format. It should look like NUDGEL-XXXX-XXXX-XXXX.");
  }

  bumpRateLimit(normEmail, "verify", 5, 900_000); // 5 attempts / 15 min

  // Look up UID by email
  const userDoc = await withTimeout(getDoc(doc(db, "recovery_by_email", normEmail)), 10000, "Account lookup");
  if (!userDoc.exists()) {
    throw new Error("No account found with this email.");
  }
  const uid = userDoc.data().uid as string;
  if (!uid) throw new Error("No account found with this email.");

  // Get the stored token
  const tokenDoc = await withTimeout(getDoc(doc(db, "recovery_tokens", uid)), 10000, "Token lookup");
  if (!tokenDoc.exists()) {
    throw new Error("No recovery token found for this account.");
  }
  const data = tokenDoc.data() as any;

  const providedHash = await hashToken(normToken);
  if (providedHash !== data.tokenHash) {
    throw new Error("Invalid recovery token.");
  }

  return { uid };
}

/**
 * STEP 2 of recovery: reset password using the verified token.
 *
 * Note: Firebase Web SDK requires authentication to call updatePassword().
 * Since the user is not signed in (that's the point of "forgot password"),
 * we use a sign-in helper: if the user provides their old password in addition
 * to the recovery token, we can sign them in and update. Otherwise we
 * generate a temporary signed-in session using a Cloud Function.
 *
 * For this implementation, we sign them in by attempting to re-create the
 * session. The user must remember their old password.
 *
 * Alternative: We call a Cloud Function with the recovery token to set the
 * new password without the user being signed in.
 */
export async function resetPasswordWithRecoveryToken(
  email: string,
  token: string,
  newPassword: string
): Promise<{ uid: string; newRecoveryToken: string }> {
  const normEmail = email.toLowerCase().trim();
  bumpRateLimit(normEmail, "reset", 3, 900_000); // 3 attempts / 15 min

  if (newPassword.length < 8) throw new Error("Password must be at least 8 characters.");
  if (!/[A-Z]/.test(newPassword)) throw new Error("Include at least one uppercase letter.");
  if (!/[0-9]/.test(newPassword)) throw new Error("Include at least one number.");

  const { uid } = await verifyRecoveryToken(email, token);

  // Try to update the password — only works if the user is currently signed in
  // with the same email. Otherwise throw a clear error.
  const current = auth.currentUser;
  if (!current || current.email?.toLowerCase() !== normEmail) {
    throw new Error(
      "To complete the password reset, please sign in with your current password first, " +
      "then use the recovery token from Settings. " +
      "Alternatively, a Firebase Cloud Function can reset the password without sign-in."
    );
  }

  try {
    await updatePassword(current, newPassword);
  } catch (e: any) {
    if (e.code === "auth/requires-recent-login") {
      throw new Error("Please sign out, sign back in, then try again.");
    }
    throw e;
  }

  // Mark old token as used
  await withTimeout(updateDoc(doc(db, "recovery_tokens", uid), {
    used: true,
    usedAt: serverTimestamp(),
  }), 10000, "Invalidating old token");

  // Generate a new recovery token
  const newRecoveryToken = await generateAndStoreRecoveryToken(uid, normEmail);

  // Clear rate limit on success
  resetRateLimit(normEmail, "verify");
  resetRateLimit(normEmail, "reset");

  return { uid, newRecoveryToken };
}

/**
 * Regenerate the recovery token from Settings (requires sign-in).
 */
export async function regenerateRecoveryToken(currentPassword?: string): Promise<string> {
  const current = auth.currentUser;
  if (!current) throw new Error("You must be signed in to regenerate your token.");

  // If we have a password, re-authenticate to ensure freshness
  if (currentPassword && current.email) {
    try {
      const { EmailAuthProvider, reauthenticateWithCredential } = await import("firebase/auth");
      const cred = EmailAuthProvider.credential(current.email, currentPassword);
      await reauthenticateWithCredential(current, cred);
    } catch (e: any) {
      if (e.code === "auth/wrong-password") throw new Error("Incorrect password.");
      throw e;
    }
  }

  // Invalidate old token (set used=true) and generate new
  try {
    const oldDoc = await withTimeout(getDoc(doc(db, "recovery_tokens", current.uid)), 8000, "Reading old token");
    if (oldDoc.exists()) {
      await withTimeout(updateDoc(doc(db, "recovery_tokens", current.uid), {
        used: true,
        invalidatedAt: serverTimestamp(),
      }), 8000, "Invalidating old token");
    }
  } catch (e: any) {
    // If reading fails because the doc doesn't exist or rules block read,
    // continue — setDoc in generateAndStoreRecoveryToken overwrites anyway.
    console.warn("[Recovery] Old token check failed, continuing:", e.message);
  }

  return await generateAndStoreRecoveryToken(current.uid, current.email || "");
}

// ===========================================================
// HELPERS
// ===========================================================
function toAuthUser(user: FirebaseUser, recoveryToken?: string | null): AuthUser {
  return {
    uid: user.uid,
    name: user.displayName || user.email?.split("@")[0] || "User",
    email: user.email || "",
    emailVerified: user.emailVerified,
    photoURL: user.photoURL,
    createdAt: user.metadata.creationTime || new Date().toISOString(),
    lastSignIn: user.metadata.lastSignInTime || new Date().toISOString(),
    recoveryToken: recoveryToken ?? null,
  };
}
