import { useState, useRef, useEffect, useCallback } from 'react';

/* ============================ ICONS ============================ */
const I = {
  Search: ({ s = 16 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
      <circle cx="11" cy="11" r="7.5"/><path d="m20.5 20.5-4-4"/>
    </svg>
  ),
  Tune: ({ s = 17 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
      <path d="M21 5H10M6 5H3M21 12h-3M13 12H3M21 19h-7M9 19H3"/>
      <circle cx="8" cy="5" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="11" cy="19" r="2"/>
    </svg>
  ),
  Plus: ({ s = 18 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.8" strokeLinecap="round">
      <path d="M12 5v14M5 12h14"/>
    </svg>
  ),
  ChevronLeft: ({ s = 24 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="m15 18-6-6 6-6"/>
    </svg>
  ),
  Video: ({ s = 20 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m22 8-6 4 6 4V8Z"/><rect width="14" height="12" x="2" y="6" rx="2" ry="2"/>
    </svg>
  ),
  More: ({ s = 20 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/>
    </svg>
  ),
  Lock: ({ s = 12 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
    </svg>
  ),
  Smile: ({ s = 20 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" x2="9.01" y1="9" y2="9"/><line x1="15" x2="15.01" y1="9" y2="9"/>
    </svg>
  ),
  Camera: ({ s = 20 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/>
    </svg>
  ),
  Mic: ({ s = 20 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/>
    </svg>
  ),
  DoubleCheck: ({ s = 14 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 6 7 17l-5-5"/><path d="m22 10-7.5 7.5L13 16"/>
    </svg>
  ),
  X: ({ s = 14 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
      <path d="M18 6 6 18M6 6l12 12"/>
    </svg>
  ),
  Send: ({ s = 18 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
      <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
    </svg>
  ),
  User: ({ s = 20 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
    </svg>
  ),
  Star: ({ s = 12, filled }: { s?: number; filled?: boolean }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill={filled ? "currentColor" : "none"} stroke="currentColor" strokeWidth={filled ? "0" : "2"}>
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
    </svg>
  ),
  Mute: ({ s = 12 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 5 6 9H2v6h4l5 4V5Z"/><path d="m22 9-6 6M16 9l6 6"/>
    </svg>
  ),
  Pin: ({ s = 13 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 17v5M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1Z"/>
    </svg>
  ),
  Chat: ({ s = 20 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
      <circle cx="8.5" cy="11.5" r="0.9" fill="currentColor" stroke="none"/>
      <circle cx="12" cy="11.5" r="0.9" fill="currentColor" stroke="none"/>
      <circle cx="15.5" cy="11.5" r="0.9" fill="currentColor" stroke="none"/>
    </svg>
  ),
  Phone: ({ s = 20 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
    </svg>
  ),
  People: ({ s = 20 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
      <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
    </svg>
  ),
  Gear: ({ s = 20 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.1a2 2 0 0 1-1-1.72v-.51a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/>
      <circle cx="12" cy="12" r="3"/>
    </svg>
  ),
  Sparkle: ({ s = 12 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 1.5l1.8 5.7 5.7 1.8-5.7 1.8L12 16.5l-1.8-5.7L4.5 9l5.7-1.8zM19.5 14l.9 2.85 2.85.9-2.85.9-.9 2.85-.9-2.85-2.85-.9 2.85-.9z"/>
    </svg>
  ),
  Check: ({ s = 14 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 6 9 17l-5-5"/>
    </svg>
  ),
};

/* ============================ COMPONENTS ============================ */

type Message = {
  id: number;
  text: string;
  time: string;
  sender: 'me' | 'them';
  status?: 'sent' | 'read';
  reaction?: string;
};

const INITIAL_MESSAGES: Message[] = [
  { id: 1, text: "Hey! How's it going? 👋", time: '9:30 AM', sender: 'them' },
  { id: 2, text: "Hey Aarav! All good, thanks 😊\nHow about you?", time: '9:31 AM', sender: 'me', status: 'read' },
  { id: 3, text: "Doing great! Just finished a\nworkout. Feeling energized 💪", time: '9:32 AM', sender: 'them' },
  { id: 4, text: "That's awesome! 🔥\nWhat's the plan for the weekend?", time: '9:32 AM', sender: 'me', status: 'read' },
  { id: 5, text: "Thinking of a short trek on Sunday.\nYou in? 🏔️", time: '9:33 AM', sender: 'them' },
  { id: 6, text: "Definitely! Count me in.\nSend details when you can 👍", time: '9:34 AM', sender: 'me', status: 'read', reaction: '❤️ 1' },
  { id: 7, text: "Sure thing! Will do.\nCatch you later! 👋", time: '9:34 AM', sender: 'them' },
];

const REPLIES = [
  "Haha, nice one! 😄",
  "Sounds good to me! 👍",
  "Sure, let's do it! 🙌",
  "On it! Give me a sec ⏳",
  "Love that idea ✨",
  "Okay okay, deal 🤝",
];

const formatNow = () => {
  const d = new Date();
  let h = d.getHours();
  const m = d.getMinutes().toString().padStart(2, '0');
  const ap = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return `${h}:${m} ${ap}`;
};

const ChatInterface = ({ contact, onBack }: { contact: any, onBack: () => void }) => {
  const [msg, setMsg] = useState('');
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const nextId = useRef(100);
  const replyIdx = useRef(0);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    const el = scrollRef.current;
    if (el) {
      requestAnimationFrame(() => {
        el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
      });
    }
  }, [messages, typing]);

  const sendMessage = useCallback(() => {
    const text = msg.trim();
    if (!text) return;
    const myMsg: Message = { id: nextId.current++, text, time: formatNow(), sender: 'me', status: 'sent' };
    setMessages(prev => [...prev, myMsg]);
    setMsg('');

    // Mark as read shortly after
    setTimeout(() => {
      setMessages(prev => prev.map(m => m.id === myMsg.id ? { ...m, status: 'read' } : m));
    }, 900);

    // Simulated typing + reply
    setTimeout(() => setTyping(true), 1200);
    setTimeout(() => {
      setTyping(false);
      const reply = REPLIES[replyIdx.current % REPLIES.length];
      replyIdx.current++;
      setMessages(prev => [...prev, { id: nextId.current++, text: reply, time: formatNow(), sender: 'them' }]);
    }, 2600);
  }, [msg]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const hasText = msg.trim().length > 0;

  return (
    <div className="absolute inset-0 z-[60] flex flex-col bg-[#050403] rise-in overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between gap-2 px-3 py-3 flex-shrink-0" style={{ background: 'rgba(11, 9, 7, 0.95)', backdropFilter: 'blur(10px)', borderBottom: '1px solid rgba(216,173,90,0.1)' }}>
        <div className="flex items-center gap-1.5 min-w-0">
          <button onClick={onBack} className="tappable-soft p-1 text-[#D4A853] flex-shrink-0">
            <I.ChevronLeft s={26} />
          </button>
          <div className="flex items-center gap-2.5 min-w-0">
            <GoldAvatar img={contact.img} size={40} online={contact.online} />
            <div className="flex flex-col min-w-0">
              <div className="flex items-center gap-1.5 min-w-0">
                <span className="text-[14.5px] font-bold text-[#F3EADB] truncate">{contact.name}</span>
                <span className="text-[#D4A853] flex-shrink-0"><I.Star s={12} filled /></span>
              </div>
              <span className="text-[11px] font-medium text-[#34B45E]">Online</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1 text-[#D4A853] flex-shrink-0">
          <button className="tappable-soft w-9 h-9 flex items-center justify-center"><I.Phone s={20} /></button>
          <button className="tappable-soft w-9 h-9 flex items-center justify-center"><I.Video s={21} /></button>
          <button className="tappable-soft w-9 h-9 flex items-center justify-center"><I.More s={20} /></button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div ref={scrollRef} className="flex-1 scroll-area px-4 py-4 min-h-0">
        {/* Encryption Note */}
        <div className="flex flex-col items-center gap-2 mb-6">
          <div className="flex items-center gap-1.5 text-[#D4A853]">
            <I.Lock s={12} />
            <span className="text-[11px] font-bold uppercase tracking-wider">End-to-end encrypted</span>
          </div>
          <p className="text-[11px] text-[#6E6353] text-center max-w-[240px] leading-relaxed">
            Messages and calls are secured with end-to-end encryption. <span className="text-[#D4A853]">Learn more</span>
          </p>
        </div>

        {/* Date Divider */}
        <div className="flex justify-center mb-6">
          <span className="px-4 py-1 rounded-full bg-[#1A1814] text-[11px] font-bold text-[#6E6353]">Today</span>
        </div>

        <div className="space-y-5">
          {messages.map((m) => (
            <div key={m.id} className={`flex flex-col msg-in ${m.sender === 'me' ? 'items-end' : 'items-start'}`}>
              <div className="relative max-w-[85%]">
                <div
                  className={`px-4 py-2.5 rounded-[22px] text-[14px] leading-relaxed whitespace-pre-wrap break-words ${
                    m.sender === 'me'
                      ? 'gold-solid text-black rounded-tr-md font-medium'
                      : 'bg-[#1A1814] text-[#F3EADB] rounded-tl-md font-medium'
                  }`}
                  style={m.sender === 'me' ? { textShadow: 'none' } : { border: '1px solid rgba(255,255,255,0.05)' }}
                >
                  {m.text}
                </div>

                <div className={`flex items-center gap-1.5 mt-1.5 ${m.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
                  <span className="text-[10px] font-bold text-[#6E6353]">{m.time}</span>
                  {m.sender === 'me' && (
                    <span className={m.status === 'read' ? 'text-[#34B45E]' : 'text-[#6E6353]'} style={{ transition: 'color 0.4s ease' }}>
                      <I.DoubleCheck s={14} />
                    </span>
                  )}
                </div>

                {m.reaction && (
                  <div className="absolute -bottom-2 -right-1 px-2 py-0.5 rounded-full bg-[#1A1814] text-[10px] flex items-center gap-1" style={{ border: '1px solid rgba(216,173,90,0.2)', boxShadow: '0 2px 8px rgba(0,0,0,0.5)' }}>
                    {m.reaction}
                  </div>
                )}
              </div>
            </div>
          ))}

          {/* Typing indicator */}
          {typing && (
            <div className="flex items-start msg-in">
              <div className="bg-[#1A1814] rounded-[22px] rounded-tl-md px-4 py-3.5 flex items-center gap-1.5" style={{ border: '1px solid rgba(255,255,255,0.05)' }}>
                <span className="typing-dot" />
                <span className="typing-dot" style={{ animationDelay: '0.18s' }} />
                <span className="typing-dot" style={{ animationDelay: '0.36s' }} />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Input Area */}
      <div className="px-3 pb-6 pt-2 flex-shrink-0" style={{ background: 'rgba(5,4,3,0.97)' }}>
        <div className="flex items-center gap-2.5">
          <button className="tappable-soft w-[42px] h-[42px] rounded-full flex items-center justify-center text-[#D4A853] flex-shrink-0" style={{ border: '1.5px solid rgba(216,173,90,0.35)' }}>
            <I.Plus s={20} />
          </button>

          <div className="flex-1 luxe-surface h-[44px] rounded-full pl-4 pr-2 flex items-center gap-2 min-w-0">
            <input
              type="text"
              value={msg}
              onChange={(e) => setMsg(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a message..."
              className="flex-1 bg-transparent text-[14px] font-medium text-[#F3EADB] placeholder-[#6E6353] outline-none min-w-0"
            />
            <button className="tappable-soft w-8 h-8 flex items-center justify-center text-[#6E6353] hover:text-[#D4A853] transition-colors flex-shrink-0"><I.Smile s={19} /></button>
            <button className="tappable-soft w-8 h-8 flex items-center justify-center text-[#6E6353] hover:text-[#D4A853] transition-colors flex-shrink-0"><I.Camera s={19} /></button>
          </div>

          <button
            onClick={sendMessage}
            className="gold-solid tappable w-[44px] h-[44px] rounded-full flex items-center justify-center text-black flex-shrink-0"
            aria-label={hasText ? 'Send message' : 'Voice message'}
          >
            <span className={`send-swap ${hasText ? 'send-mode' : ''}`}>
              {hasText ? <I.Send s={18} /> : <I.Mic s={20} />}
            </span>
          </button>
        </div>
        {/* Home indicator */}
        <div className="flex justify-center pt-3">
          <span className="w-[110px] h-[4px] rounded-full" style={{ background: 'rgba(243,234,219,0.28)' }} />
        </div>
      </div>
    </div>
  );
};

/* ============================ DATA ============================ */
const AVATARS = {
  me: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&h=120&fit=crop',
  aarav: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=160&h=160&fit=crop',
  diya: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=160&h=160&fit=crop',
  kabir: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=160&h=160&fit=crop',
  ananya: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=160&h=160&fit=crop',
  circle: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=160&h=160&fit=crop',
  friends: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=160&h=160&fit=crop',
  photo: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=120&h=120&fit=crop',
};

type Chat = {
  img: string; name: string; msg: string; time: string;
  unread?: number; online?: boolean; star?: boolean; muted?: boolean;
  pinned?: boolean; photo?: boolean; group?: boolean; mention?: boolean;
};

const CHATS: Chat[] = [
  { img: AVATARS.aarav, name: 'Aarav Mehta', msg: "Let's catch up over coffee this weekend? ☕", time: '9:40 AM', unread: 2, online: true, star: true },
  { img: AVATARS.diya, name: 'Diya Shah', msg: 'That sounds amazing! ✨', time: '9:32 AM', online: true, pinned: true },
  { img: AVATARS.circle, name: 'Project Phoenix', msg: 'Rohan: Please review the latest slides.', time: 'Yesterday', unread: 8, muted: true, group: true, mention: true },
  { img: AVATARS.kabir, name: 'Kabir Singh', msg: 'Shared a photo', time: 'Yesterday', photo: true },
  { img: AVATARS.ananya, name: 'Ananya Iyer', msg: 'Thank you so much! 😊', time: 'Tue', online: true, unread: 1 },
  { img: AVATARS.friends, name: 'Friends Forever', msg: 'Diya: Hahaha true 😂', time: 'Mon', unread: 3, muted: true, group: true, mention: true },
  { img: AVATARS.kabir, name: 'Design Guild', msg: 'Kabir: Final tokens are pushed 🎨', time: 'Mon', group: true },
  { img: AVATARS.diya, name: 'Diya · Work', msg: 'Sent the invoice, check inbox.', time: 'Sun', unread: 1, mention: true },
  { img: AVATARS.aarav, name: 'Aarav · Gym', msg: 'Leg day tomorrow 6 AM. No excuses.', time: 'Sun', online: true },
  { img: AVATARS.circle, name: 'Family Circle', msg: 'Mom: Dinner at 8, everyone!', time: 'Sat', group: true, muted: true },
];

const STORIES = [
  { name: 'New Nudge', newNudge: true },
  { name: 'My Circle', img: AVATARS.circle, active: true },
  { name: 'Aarav', img: AVATARS.aarav, online: true },
  { name: 'Diya', img: AVATARS.diya, online: true },
  { name: 'Kabir', img: AVATARS.kabir },
  { name: 'Ananya', img: AVATARS.ananya, online: true },
];

/* ============================ ATOMS ============================ */
const GoldAvatar = ({ img, size, online, dim, flow }: { img: string; size: number; online?: boolean; dim?: boolean; flow?: boolean }) => (
  <div className="relative flex-shrink-0">
    <div
      className={!dim && flow ? 'gold-ring-flow' : undefined}
      style={{
        width: size,
        height: size,
        borderRadius: '50%',
        padding: 2,
        background: dim
          ? 'linear-gradient(160deg, #3A332A, #221E18)'
          : flow
            ? undefined
            : 'conic-gradient(from 210deg, #8F6420 0%, #D9AE5F 12%, #FFF0CC 25%, #E2B566 38%, #9C7126 52%, #C8963F 68%, #F3D392 80%, #B07F2C 92%, #8F6420 100%)',
        boxShadow: dim
          ? 'none'
          : flow
            ? undefined
            : '0 0 8px rgba(216,173,90,0.15), 0 2px 6px rgba(0,0,0,0.5)',
      }}
    >
      <div style={{ width: '100%', height: '100%', borderRadius: '50%', padding: 1.5, background: '#0C0A07' }}>
        <img src={img} alt="" className="w-full h-full object-cover rounded-full" draggable={false} />
      </div>
    </div>
    {online && (
      <span
        className="online-dot absolute rounded-full"
        style={{ width: size * 0.24, height: size * 0.24, bottom: size * 0.02, right: size * 0.02, border: '2px solid #0B0907' }}
      />
    )}
  </div>
);

const GoldBadge = ({ n, small }: { n: number; small?: boolean }) => (
  <span
    className="gold-solid inline-flex items-center justify-center rounded-full font-extrabold text-black flex-shrink-0"
    style={{
      minWidth: small ? 17 : 22, height: small ? 17 : 22,
      fontSize: small ? 10 : 11, padding: '0 5px',
      textShadow: '0 1px 0 rgba(255,243,214,0.55)',
    }}
  >
    {n}
  </span>
);

/* ============================ SECTIONS ============================ */

const Header = () => (
  <div className="flex items-center justify-between px-5 pt-4 pb-3 flex-shrink-0">
    <h1 className="logo-shimmer text-[28px] font-extrabold tracking-[-0.03em] leading-none select-none flex items-center gap-1.5">
      Nudgel
      <span className="text-[#F0CC85]" style={{ filter: 'drop-shadow(0 0 3px rgba(240,204,133,0.6))' }}>
        <I.Sparkle s={12} />
      </span>
    </h1>
    <div className="flex items-center gap-2.5">
      <button className="tappable-soft relative" aria-label="Profile">
        <GoldAvatar img={AVATARS.me} size={38} />
        <span
          className="absolute -bottom-0.5 -right-0.5 w-[11px] h-[11px] rounded-full gold-solid"
          style={{ border: '2px solid #0B0907' }}
        />
      </button>
    </div>
  </div>
);

const SearchRow = () => (
  <div className="px-4 pb-2.5 flex-shrink-0">
    <div className="luxe-surface flex items-center gap-3 rounded-2xl px-4 h-[42px]">
      <span className="text-[#8A7D67]"><I.Search s={17} /></span>
      <input
        type="text"
        placeholder="Search Nudges or people"
        className="flex-1 bg-transparent text-[13px] font-medium text-[#F3EADB] placeholder-[#6E6353] outline-none min-w-0"
      />
    </div>
  </div>
);

const Stories = () => (
  <div className="flex-shrink-0">
    <div className="scroll-x flex gap-4 px-4 pb-1.5 items-start">
      {STORIES.map((s, i) => (
        <button key={i} className="tappable-soft flex flex-col items-center gap-1.5 flex-shrink-0 w-[64px]">
          {'newNudge' in s && s.newNudge ? (
            <div className="relative">
              <div className="gold-stroke-flow rounded-[19px] p-[1.5px] shadow-[0_0_12px_rgba(216,173,90,0.18),0_4px_10px_rgba(0,0,0,0.5)]">
                <div
                  className="w-[58px] h-[58px] rounded-[18px] flex items-center justify-center"
                  style={{
                    background: 'linear-gradient(165deg, #221D15 0%, #161209 100%)',
                    boxShadow: '0 1px 0 rgba(255,235,190,0.08) inset',
                  }}
                >
                  <span className="text-[#EFC878]"><I.Chat s={24} /></span>
                </div>
              </div>
              <span className="absolute -top-1 -right-1 text-[#FFE9B8]" style={{ filter: 'drop-shadow(0 0 4px rgba(255,233,184,0.7))' }}>
                <I.Sparkle s={14} />
              </span>
            </div>
          ) : (
            <GoldAvatar img={(s as any).img} size={58} online={(s as any).online} dim={!(s as any).active && !(s as any).online} flow={!(!(s as any).active && !(s as any).online)} />
          )}
          <span className={`text-[10.5px] font-semibold leading-tight truncate w-full text-center ${(s as any).active ? 'text-[#EFC878]' : 'text-[#9B8F7C]'}`}>
            {s.name}
          </span>
          {(s as any).active && (
            <span className="grow-bar gold-line-flow block w-5 h-[2.5px] rounded-full -mt-0.5" />
          )}
        </button>
      ))}
    </div>
  </div>
);

const ChatRow = ({ c, delay }: { c: Chat; delay: number }) => (
  <button
    className="chat-row rise-in w-full flex items-center gap-3 px-3 py-[10px] rounded-[18px] text-left"
    style={{ animationDelay: `${delay}ms` }}
  >
    <GoldAvatar img={c.img} size={48} online={c.online} dim={!c.unread && !c.star} />
    <div className="flex-1 min-w-0">
      <div className="flex items-center justify-between gap-2 mb-[2px]">
        <span className="flex items-center gap-1.5 min-w-0">
          <span className="text-[13.5px] font-bold text-[#F3EADB] truncate tracking-[-0.01em]">{c.name}</span>
          {c.star && (
            <span className="text-[#EFC878] flex-shrink-0" style={{ filter: 'drop-shadow(0 0 3px rgba(239,200,120,0.55))' }}>
              <I.Star s={11} />
            </span>
          )}
          {c.muted && <span className="text-[#5A5142] flex-shrink-0"><I.Mute s={11} /></span>}
        </span>
        <span className={`text-[10.5px] font-semibold flex-shrink-0 ${c.unread ? 'text-[#C9A969]' : 'text-[#6E6353]'}`}>
          {c.time}
        </span>
      </div>
      <div className="flex items-center justify-between gap-2">
        <span className={`text-[12px] truncate ${c.unread ? 'text-[#C9BCA6] font-semibold' : 'text-[#80755F] font-medium'}`}>
          {c.mention && <span className="text-[#EFC878] font-bold mr-1">@</span>}
          {c.msg}
        </span>
        <span className="flex items-center gap-1.5 flex-shrink-0">
          {c.pinned && <span className="text-[#6E6353]"><I.Pin s={13} /></span>}
          {c.photo && (
            <span
              className="block w-[30px] h-[22px] rounded-md overflow-hidden"
              style={{ border: '1.5px solid rgba(216,173,90,0.3)', boxShadow: '0 2px 5px rgba(0,0,0,0.5)' }}
            >
              <img src={AVATARS.photo} alt="" className="w-full h-full object-cover" draggable={false} />
            </span>
          )}
          {c.unread ? <GoldBadge n={c.unread} /> : null}
        </span>
      </div>
    </div>
  </button>
);

const NAV = [
  { id: 'chats', label: 'Chats', icon: I.Chat, badge: 12 },
  { id: 'calls', label: 'Calls', icon: I.Phone },
  { id: 'center', label: '', icon: null },
  { id: 'people', label: 'People', icon: I.People },
  { id: 'settings', label: 'Settings', icon: I.Gear },
];

/* ============================ BOTTOM SHEET ============================ */
const SUGGESTIONS = [
  { name: 'Aarav Mehta', avatar: AVATARS.aarav },
  { name: 'Diya Shah', avatar: AVATARS.diya },
  { name: 'Kabir Singh', avatar: AVATARS.kabir },
  { name: 'Ananya Iyer', avatar: AVATARS.ananya },
];

const BottomSheet = ({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) => {
  const [mode, setMode] = useState<'button' | 'input'>('button');
  const [inputValue, setInputValue] = useState('');
  const [tokens, setTokens] = useState<{ id: number; label: string; avatar?: string }[]>([]);
  const [removingId, setRemovingId] = useState<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const nextId = useRef(1);

  // When opening, focus input after morph completes
  useEffect(() => {
    if (isOpen && mode === 'input') {
      const t = setTimeout(() => inputRef.current?.focus(), 350);
      return () => clearTimeout(t);
    }
  }, [isOpen, mode]);

  // When closing, reset after animation
  useEffect(() => {
    if (!isOpen) {
      const t = setTimeout(() => {
        setMode('button');
        setInputValue('');
        setTokens([]);
        setRemovingId(null);
      }, 500);
      return () => clearTimeout(t);
    }
  }, [isOpen]);

  const handleAddToken = useCallback(() => {
    const v = inputValue.trim();
    if (!v) return;
    // Check if it matches a suggestion
    const match = SUGGESTIONS.find(s => s.name.toLowerCase().includes(v.toLowerCase()));
    setTokens(prev => [...prev, { id: nextId.current++, label: v, avatar: match?.avatar }]);
    setInputValue('');
    nextId.current++;
  }, [inputValue]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddToken();
    }
    if (e.key === ',' || e.key === ';') {
      e.preventDefault();
      const v = inputValue.replace(/[;,]/g, '').trim();
      if (v) {
        const match = SUGGESTIONS.find(s => s.name.toLowerCase().includes(v.toLowerCase()));
        setTokens(prev => [...prev, { id: nextId.current++, label: v, avatar: match?.avatar }]);
        setInputValue('');
      }
    }
    if (e.key === 'Backspace' && !inputValue && tokens.length > 0) {
      // Remove last token with animation
      const last = tokens[tokens.length - 1];
      setRemovingId(last.id);
      setTimeout(() => {
        setTokens(prev => prev.filter(t => t.id !== last.id));
        setRemovingId(null);
      }, 250);
    }
  }, [inputValue, tokens, handleAddToken]);

  const removeToken = useCallback((id: number) => {
    setRemovingId(id);
    setTimeout(() => {
      setTokens(prev => prev.filter(t => t.id !== id));
      setRemovingId(null);
    }, 250);
  }, []);

  const handleSend = useCallback(() => {
    // In a real app, this would create a conversation
    // For now, just close
    onClose();
  }, [onClose]);

  const tokenCount = tokens.length;

  return (
    <>
      {/* Backdrop */}
      <div
        className={`absolute inset-0 z-40 transition-opacity duration-[500ms] ${isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
        style={{ background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)' }}
        onClick={() => { onClose(); }}
      />

      {/* Sheet */}
      <div
        className={`absolute inset-x-0 bottom-0 z-50 transition-transform duration-[550ms] cubic-bezier(0.32, 0.72, 0, 1) ${isOpen ? 'translate-y-0' : 'translate-y-full'}`}
        style={{ willChange: 'transform' }}
      >
        {/* Sheet surface */}
        <div
          className="relative px-5 pb-7 pt-3"
          style={{
            background: 'linear-gradient(178deg, #1E1A14 0%, #14110D 40%, #0F0D0A 100%)',
            borderRadius: '32px 32px 0 0',
            border: '1px solid rgba(216,173,90,0.15)',
            borderBottom: 'none',
            boxShadow: '0 -4px 30px rgba(0,0,0,0.6), 0 -12px 60px rgba(0,0,0,0.35), 0 1px 0 rgba(255,235,190,0.08) inset',
            maxHeight: '55vh',
          }}
          onClick={e => e.stopPropagation()}
        >
          {/* Handle bar */}
          <div className="flex justify-center pb-4">
            <span className="w-10 h-1 rounded-full" style={{ background: 'rgba(243,234,219,0.3)' }} />
          </div>

          {/* Title */}
          <div className="mb-5 px-1">
            <h2 className="text-[18px] font-bold text-[#F3EADB] tracking-tight">
              {mode === 'button' ? 'New Nudge' : 'Add People'}
            </h2>
            <p className="text-[12px] text-[#8A7D67] mt-0.5 font-medium">
              {mode === 'button' ? 'Start a conversation or add people to a circle.' : 'Invite people by email, username, or phone number.'}
            </p>
          </div>

          {/* Content area */}
          <div className="transition-all duration-400 ease-out">
            {/* Mode: Add Person Button */}
            {mode === 'button' && (
              <div className="flex flex-col items-center gap-4">
                {/* Suggestions */}
                <div className="w-full">
                  <p className="text-[11px] font-semibold text-[#6E6353] uppercase tracking-wider mb-3 px-1">Suggestions</p>
                  <div className="flex gap-3 overflow-x-auto scroll-x pb-2">
                    {SUGGESTIONS.map((s, i) => (
                      <button
                        key={i}
                        onClick={() => {
                          setTokens(prev => [...prev, { id: nextId.current++, label: s.name, avatar: s.avatar }]);
                          setMode('input');
                        }}
                        className="tappable-soft flex flex-col items-center gap-2 flex-shrink-0"
                      >
                        <GoldAvatar img={s.avatar} size={50} />
                        <span className="text-[10.5px] font-semibold text-[#C9BCA6]">{s.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Primary Add Person Button */}
                <button
                  onClick={() => setMode('input')}
                  className="gold-solid tappable w-full h-[52px] rounded-2xl flex items-center justify-center gap-2.5 text-black mt-2"
                  style={{ textShadow: '0 1px 0 rgba(255,243,214,0.55)' }}
                >
                  <I.Plus s={20} />
                  <span className="text-[15px] font-bold">Add Person</span>
                </button>
              </div>
            )}

            {/* Mode: Token Input */}
            {mode === 'input' && (
              <div className="flex flex-col gap-3">
                {/* Token container */}
                <div
                  className="min-h-[50px] p-3 rounded-2xl flex flex-wrap gap-2 items-start content-start"
                  style={{
                    background: 'linear-gradient(178deg, #1B1814 0%, #14110D 100%)',
                    border: `1.5px solid ${tokenCount > 0 ? 'rgba(216,173,90,0.3)' : 'rgba(216,173,90,0.14)'}`,
                    boxShadow: tokenCount > 0 ? '0 0 16px rgba(216,173,90,0.12)' : 'none',
                    transition: 'all 0.4s ease',
                  }}
                  onClick={() => inputRef.current?.focus()}
                >
                  {/* Tokens */}
                  {tokens.map(token => (
                    <span
                      key={token.id}
                      className={`inline-flex items-center gap-1.5 pl-0.5 pr-1 py-1 rounded-full text-[12px] font-bold text-[#F3EADB] transition-all duration-[300ms] ease-out ${
                        removingId === token.id ? 'token-exit' : 'token-enter'
                      }`}
                      style={{
                        background: 'linear-gradient(178deg, #2A2520 0%, #1E1A14 100%)',
                        border: '1.5px solid rgba(216,173,90,0.35)',
                        boxShadow: '0 0 10px rgba(216,173,90,0.15), 0 2px 6px rgba(0,0,0,0.4)',
                      }}
                    >
                      {token.avatar ? (
                        <img src={token.avatar} alt="" className="w-[22px] h-[22px] rounded-full object-cover" draggable={false} />
                      ) : (
                        <span className="w-[22px] h-[22px] rounded-full gold-solid flex items-center justify-center">
                          <span className="text-[10px] text-black font-black leading-none">{token.label[0]?.toUpperCase()}</span>
                        </span>
                      )}
                      <span>{token.label}</span>
                      <button
                        onClick={(e) => { e.stopPropagation(); removeToken(token.id); }}
                        className="ml-0.5 w-[18px] h-[18px] rounded-full flex items-center justify-center text-[#8A7D67] hover:text-[#EFC878] hover:bg-[#EFC878]/10 transition-colors flex-shrink-0"
                      >
                        <I.X s={11} />
                      </button>
                    </span>
                  ))}

                  {/* Input */}
                  <input
                    ref={inputRef}
                    type="text"
                    value={inputValue}
                    onChange={e => setInputValue(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder={tokens.length === 0 ? 'Email, username, or phone number...' : 'Add another...'}
                    className="flex-1 min-w-[120px] bg-transparent text-[13px] font-medium text-[#F3EADB] placeholder-[#6E6353] outline-none py-1"
                  />
                </div>

                {/* Action row */}
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setMode('button')}
                    className="flex-shrink-0 px-4 h-[42px] rounded-xl text-[#8A7D67] text-[13px] font-semibold tappable-soft"
                    style={{
                      background: 'rgba(255,255,255,0.04)',
                      border: '1px solid rgba(255,255,255,0.08)',
                    }}
                  >
                    Back
                  </button>
                  <div className="flex-1" />
                  <button
                    onClick={handleAddToken}
                    disabled={!inputValue.trim()}
                    className="flex-shrink-0 w-[42px] h-[42px] rounded-xl flex items-center justify-center tappable-soft transition-opacity"
                    style={{
                      background: inputValue.trim()
                        ? 'linear-gradient(170deg, #FFF1CC 0%, #E3B25D 42%, #A87527 82%)'
                        : 'rgba(255,255,255,0.06)',
                      color: inputValue.trim() ? '#1A1206' : '#3A332A',
                      opacity: inputValue.trim() ? 1 : 0.4,
                      boxShadow: inputValue.trim() ? '0 2px 8px rgba(216,173,90,0.35), inset 0 1px 0 rgba(255,248,220,0.5) inset' : 'none',
                    }}
                  >
                    <I.Plus s={18} />
                  </button>
                  <button
                    onClick={handleSend}
                    disabled={tokens.length === 0}
                    className="gold-solid tappable flex-shrink-0 h-[42px] px-6 rounded-xl flex items-center justify-center gap-2 text-black"
                    style={{
                      textShadow: '0 1px 0 rgba(255,243,214,0.55)',
                      opacity: tokens.length > 0 ? 1 : 0.35,
                      boxShadow: tokens.length > 0
                        ? '0 2px 8px rgba(216,173,90,0.35), inset 0 1px 0 rgba(255,248,220,0.5) inset, 0 -1px 3px rgba(90,62,14,0.4) inset'
                        : 'none',
                    }}
                  >
                    <span className="text-[13px] font-bold">Send</span>
                    <I.Send s={15} />
                  </button>
                </div>

                {/* Divider + more suggestions */}
                <div className="flex items-center gap-3 my-1">
                  <div className="h-px flex-1" style={{ background: 'rgba(216,173,90,0.12)' }} />
                  <span className="text-[10px] font-semibold text-[#6E6353] uppercase tracking-wider">Or pick someone</span>
                  <div className="h-px flex-1" style={{ background: 'rgba(216,173,90,0.12)' }} />
                </div>
                <div className="flex gap-3 overflow-x-auto scroll-x pb-1">
                  {SUGGESTIONS.filter(s => !tokens.some(t => t.label === s.name)).map((s, i) => (
                    <button
                      key={i}
                      onClick={() => {
                        setTokens(prev => [...prev, { id: nextId.current++, label: s.name, avatar: s.avatar }]);
                      }}
                      className="tappable-soft flex items-center gap-2 flex-shrink-0 px-3 py-2 rounded-xl"
                      style={{
                        background: 'rgba(255,255,255,0.03)',
                        border: '1px solid rgba(255,255,255,0.06)',
                      }}
                    >
                      <img src={s.avatar} alt="" className="w-8 h-8 rounded-full object-cover" draggable={false} />
                      <span className="text-[11.5px] font-semibold text-[#C9BCA6]">{s.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

const BottomNav = ({
  active,
  onChange,
  onPlus,
}: {
  active: string;
  onChange: (id: string) => void;
  onPlus: () => void;
}) => (
  <div className="flex-shrink-0 relative z-30 px-3 pb-1.5 pt-1">
    <div
      className="relative flex items-center justify-between rounded-[24px] px-1.5 h-[60px]"
      style={{
        background: 'linear-gradient(178deg, #1C1813 0%, #110E09 70%, #0C0A06 100%)',
        border: '1px solid rgba(216,173,90,0.18)',
        boxShadow: '0 1px 0 rgba(255,235,190,0.07) inset, 0 -1px 0 rgba(0,0,0,0.7) inset, 0 -6px 22px rgba(0,0,0,0.55), 0 2px 10px rgba(0,0,0,0.5)',
      }}
    >
      {NAV.map(item => {
        if (item.id === 'center') {
          return (
            <button
              key="center"
              aria-label="New Nudge"
              onClick={onPlus}
              className="gold-solid hero-glow tappable relative -mt-7 w-[56px] h-[56px] rounded-full flex items-center justify-center flex-shrink-0"
              style={{ border: '3.5px solid #0B0907' }}
            >
              <span
                className="absolute rounded-full pointer-events-none"
                style={{
                  top: 3.5, left: 6, right: 6, height: '42%',
                  background: 'linear-gradient(180deg, rgba(255,250,235,0.55) 0%, rgba(255,250,235,0) 100%)',
                  borderRadius: '50% 50% 45% 45%',
                }}
              />
              <span className="text-black relative" style={{ filter: 'drop-shadow(0 1px 0 rgba(255,243,214,0.6))' }}><I.Plus s={24} /></span>
            </button>
          );
        }
        const on = active === item.id;
        const Icon = item.icon!;
        return (
          <button
            key={item.id}
            onClick={() => onChange(item.id)}
            className="tappable-soft relative flex flex-col items-center justify-center gap-[2px] w-[58px] h-full"
          >
            {on && (
              <span
                className="absolute inset-x-2 inset-y-2 rounded-xl pointer-events-none"
                style={{
                  background: 'radial-gradient(ellipse at 50% 30%, rgba(216,173,90,0.18) 0%, rgba(216,173,90,0.04) 60%, transparent 100%)',
                  border: '1px solid rgba(216,173,90,0.2)',
                }}
              />
            )}
            <span className="relative">
              <span
                className={on ? 'text-[#EFC878]' : 'text-[#6E6353]'}
                style={on ? { filter: 'drop-shadow(0 0 4px rgba(239,200,120,0.45))' } : {}}
              >
                <Icon s={19} />
              </span>
              {item.badge ? (
                <span className="absolute -top-1.5 -right-2.5">
                  <GoldBadge n={item.badge} small />
                </span>
              ) : null}
            </span>
            <span className={`text-[9.5px] font-bold tracking-wide ${on ? 'text-[#EFC878]' : 'text-[#6E6353]'}`}>
              {item.label}
            </span>
          </button>
        );
      })}
    </div>
    <div className="flex justify-center pt-2">
      <span className="w-[110px] h-[4px] rounded-full" style={{ background: 'rgba(243,234,219,0.28)' }} />
    </div>
  </div>
);

/* ============================ APP ============================ */
export default function App() {
  const [tab, setTab] = useState('chats');
  const [sheetOpen, setSheetOpen] = useState(false);
  const [activeChat, setActiveChat] = useState<Chat | null>(null);

  const visibleChats = CHATS;

  return (
    <div className="h-full w-full flex items-center justify-center" style={{ background: '#050403' }}>
      <div
        className="relative w-full max-w-[420px] h-full max-h-[900px] flex flex-col overflow-hidden sm:rounded-[44px]"
        style={{
          background: 'linear-gradient(178deg, #131009 0%, #0B0907 38%, #080606 100%)',
          boxShadow: '0 0 0 1px rgba(216,173,90,0.1), 0 30px 90px rgba(0,0,0,0.9)',
        }}
      >
        <div
          className="absolute top-0 inset-x-0 h-[220px] pointer-events-none"
          style={{ background: 'radial-gradient(ellipse 90% 100% at 30% 0%, rgba(216,173,90,0.085) 0%, transparent 65%)' }}
        />
        <div
          className="absolute bottom-0 inset-x-0 h-[180px] pointer-events-none"
          style={{ background: 'radial-gradient(ellipse 80% 100% at 50% 100%, rgba(216,173,90,0.06) 0%, transparent 65%)' }}
        />

        {/* ======== FIXED TOP (compact) ======== */}
        <Header />
        <SearchRow />
        <Stories />

        <div className="flex-shrink-0 px-4 pt-2">
          <div className="h-px w-full" style={{ background: 'linear-gradient(90deg, transparent, rgba(216,173,90,0.22) 50%, transparent)' }} />
        </div>

        {/* ======== SCROLLABLE — CONTACTS (70-80% area) ======== */}
        <div className="scroll-area flex-1 min-h-0 relative px-2">
          <div className="sticky top-0 h-3 -mx-2 z-10 pointer-events-none"
            style={{ background: 'linear-gradient(180deg, #0B0907 0%, transparent 100%)' }} />
          <div className="space-y-0.5 pt-1 pb-2">
            {visibleChats.map((c, i) => (
              <div key={c.name + i} onClick={() => setActiveChat(c)}>
                <ChatRow c={c} delay={i * 40} />
              </div>
            ))}
            {visibleChats.length === 0 && (
              <div className="flex flex-col items-center gap-3 pt-16 text-[#6E6353]">
                <I.Chat s={34} />
                <span className="text-[12px] font-semibold">Nothing here yet</span>
              </div>
            )}
          </div>
        </div>

        <div className="flex-shrink-0 h-2 -mb-2 relative z-10 pointer-events-none"
          style={{ background: 'linear-gradient(0deg, #0B0907 0%, transparent 100%)' }} />

        {/* ======== FIXED BOTTOM (compact) ======== */}
        <BottomNav active={tab} onChange={setTab} onPlus={() => setSheetOpen(true)} />

        {/* ======== BOTTOM SHEET OVERLAY ======== */}
        <BottomSheet isOpen={sheetOpen} onClose={() => setSheetOpen(false)} />

        {/* ======== CHAT INTERFACE OVERLAY ======== */}
        {activeChat && (
          <ChatInterface 
            contact={activeChat} 
            onBack={() => setActiveChat(null)} 
          />
        )}
      </div>
    </div>
  );
}
